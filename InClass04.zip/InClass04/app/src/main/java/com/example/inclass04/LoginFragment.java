package com.example.inclass04;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class LoginFragment extends Fragment {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_login, container, false);

        EditText email = view.findViewById(R.id.editEmail);
        EditText password = view.findViewById(R.id.editPassword);

        Button btnLogin = view.findViewById(R.id.buttonLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view){

                DataServices.AccountRequestTask task = DataServices.login(email.getText().toString(), password.getText().toString());
                if(task.isSuccessful()){ //successful
                    DataServices.Account account = task.getAccount();
                    mUser.setLogin(account);
                } else { //not successful
                    String error = task.getErrorMessage();
                    //Toast.makeText(this, error, Toast.LENGTH_SHORT).show();
                }

            }

        });

        Button btnCreateAccount = view.findViewById(R.id.buttonCreatAccount);

        btnCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createNewAccount nextFrag = new createNewAccount();
                    getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainerView, nextFrag, "findThisFragment")
                        .commit();


            }
        });

        // Inflate the layout for this fragment
        return view;
    }
    @Override
    public void onAttach(@NonNull Context context){
        super.onAttach(context);

        if(context instanceof Iuser)
            mUser = (Iuser)context ;
    }

    Iuser mUser;

    public interface Iuser{
        void setLogin(DataServices.Account account);

    }

}