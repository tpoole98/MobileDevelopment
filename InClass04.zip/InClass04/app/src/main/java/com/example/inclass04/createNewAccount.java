package com.example.inclass04;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class createNewAccount extends Fragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_create_new_account, container, false);
        // Inflate the layout for this fragment

        EditText name = view.findViewById(R.id.editTextName);
        EditText email = view.findViewById(R.id.editTextEmail);
        EditText password = view.findViewById(R.id.editTextPassword);

        Button btnSubmit = view.findViewById(R.id.buttonSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(name != null && email != null && password != null){
                    DataServices.AccountRequestTask task = DataServices.register(name.toString(), email.toString(), password.toString());
                    mCreate.createNewAccount(task.getAccount());

                    AccountFragment nextFrag = new AccountFragment();
                    getActivity().getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragmentContainerView, nextFrag, "findThisFragment")
                            .commit();
                }


            }
        });

        Button btnCancel = view.findViewById(R.id.buttonCancel);

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LoginFragment nextFrag = new LoginFragment();
                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainerView, nextFrag, "findThisFragment")
                        .commit();

            }
        });

        return view;
    }

    @Override
    public void onAttach(@NonNull Context context){
        super.onAttach(context);

        if(context instanceof createNewAccount.Icreate)
            mCreate = (createNewAccount.Icreate)context ;
    }

    Icreate mCreate;

    public interface Icreate {
        void createNewAccount(DataServices.Account account);
    }
}