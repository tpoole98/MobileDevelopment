/*
Assignment04
 */
package com.example.inclass04;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity implements LoginFragment.Iuser, createNewAccount.Icreate {
DataServices.Account account;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Login");
    }

  public void setLogin(DataServices.Account profile) {
    account = profile;
   }

    public void createNewAccount(DataServices.Account profile) {
    account = profile;
    }
}