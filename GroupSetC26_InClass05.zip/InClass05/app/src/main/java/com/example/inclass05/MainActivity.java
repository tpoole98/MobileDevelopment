package com.example.inclass05;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;


import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static ArrayList<String> apps;
    public static String text;
    public static int number;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("App Categories");

        apps = DataServices.getAppCategories();


    }

    public static void setString(String s){
        text = s;
    }
    public static String getString(){
        return text;
    }
    public static void setNum(int n){
        number = n;
    }
    public static int getNum(){
        return number;
    }


}