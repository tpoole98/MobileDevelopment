package com.example.inclass05;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;


import java.lang.reflect.Array;
import java.util.List;

public class CustomAdapter extends ArrayAdapter<com.example.inclass05.DataServices.App> {


    public CustomAdapter(@NonNull Context context, int resource, @NonNull List<DataServices.App> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.user_row_item, parent, false);
        }
        DataServices.App app = getItem(position);

        TextView textViewName = convertView.findViewById(R.id.appName);
        TextView textViewAuthor = convertView.findViewById(R.id.artistName);
        TextView textRelease = convertView.findViewById(R.id.release);

        textViewName.setText(app.name);
        textViewAuthor.setText(app.artistName);
        textRelease.setText(app.releaseDate);

        return convertView;
    }
}
