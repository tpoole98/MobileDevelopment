package com.example.hw03;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class DisplayTask extends Fragment {

    final static public String DATA_ENTERED = "DATA ENTERED";
    int num;
    TextView name;
    TextView date;
    TextView priority;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.fragment_display_task, container, false);


        name = view.findViewById(R.id.textViewName);
        date = view.findViewById(R.id.textViewDate);
        priority = view.findViewById(R.id.textViewPriority);
            Task task;
            task = MainActivity.getTask();
            name.setText(task.name);
            date.setText(task.date);
            priority.setText(task.priority);
            num = task.num;



        view.findViewById(R.id.buttonCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ToDoList nextFrag = new ToDoList();
                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainerView, nextFrag, "findThisFragment")
                        .addToBackStack(null)
                        .commit();
            }
        });
        view.findViewById(R.id.buttonDelete).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDisplay.delete(num);
                ToDoList nextFrag = new ToDoList();
                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainerView, nextFrag, "findThisFragment")
                        .addToBackStack(null)
                        .commit();
            }
        });

            return view;
        }
    @Override
    public void onAttach(@NonNull Context context){
        super.onAttach(context);

        if(context instanceof DisplayTask.Idisplay)
            mDisplay = (DisplayTask.Idisplay)context ;
    }

        Idisplay mDisplay;

    public interface Idisplay{
        void delete(int n);

    }
}