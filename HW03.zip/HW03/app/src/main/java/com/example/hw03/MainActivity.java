/*
HW03
HW03
Tristan Lee Poole
 */
package com.example.hw03;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements ToDoList.Itask, DisplayTask.Idisplay, CreateTask.Isend {

    private static Task display;
    static ArrayList<Task> list = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("To-Do List");
        Task t = new Task("HW", "07", "High", 0);
        list.add(t);
        Task m = new Task("bn", "07", "High", 0);
        list.add(m);
        Task r = new Task("rn", "07", "High", 0);
        list.add(r);

        CustomFragment.getTask(list);
    }


    @Override
    public void setTask(Task t) {
        setTitle("Display Task");
        display = t;
    }

    public static Task getTask() {
        return display;
    }

    @Override
    public void delete(int n) {
        list.remove(n);
    }

    @Override
    public void newTask(Task a) {
        list.add(a);
    }
}