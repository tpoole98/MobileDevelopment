package com.example.hw03;

import java.io.Serializable;

public class Task implements Serializable {
    String name;
    String date;
    String priority;
    int num;
    public Task(String n, String d, String p, int num){
        this.name = n;
        this.date = d;
        this.priority = p;
        this.num = num;
    }
    public Task(){
        this.name = null;
        this.date = null;
        this.priority = null;
        this.num = 0;
    }

    public Task(String toString, String toString1, String priority) {
        this.name = toString;
        this.date = toString1;
        this.priority = priority;
        this.num = 5;
    }

    public String getName(){
        return name;
    }
    public String getDate(){
        return date;
    }
    public String getPriority(){
        return priority;
    }
    public int getNum(){
        return num;
    }

}
