package com.example.hw03;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;


public class CreateTask extends Fragment {

    EditText n;
    TextView d;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_create_task, container, false);

        n = view.findViewById(R.id.editName);
        d = view.findViewById(R.id.textViewDate1);

        view.findViewById(R.id.button3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().setTitle("To-Do List");
                getActivity().getSupportFragmentManager().popBackStack("ToDo", FragmentManager.POP_BACK_STACK_INCLUSIVE);

            }
        });

        view.findViewById(R.id.buttonSubmit1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RadioButton high = view.findViewById(R.id.rbHigh);
                RadioButton med = view.findViewById(R.id.rbMed);
                String priority;

                if (n.getText().toString() == "" || d.getText().toString() == "")
                    Toast.makeText(getActivity(), "Please Fill Out All Fields", Toast.LENGTH_SHORT).show();
                else {
                    if (high.isChecked())
                        priority = "High";
                    else if (med.isChecked())
                        priority = "Medium";
                    else
                        priority = "Low";

                    Task b = new Task(view.findViewById(R.id.editName).toString(),
                            ((TextView) view.findViewById(R.id.textViewDate1)).getText().toString(),
                            (priority));
                    mSend.newTask(b);

                    getActivity().setTitle("To-Do List");
                    getActivity().getSupportFragmentManager().popBackStack("ToDo1", FragmentManager.POP_BACK_STACK_INCLUSIVE);

                }
            }
        });


        view.findViewById(R.id.buttonSetDate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog();
            }
        });
return view;
    }

    public void DatePickerDialog(){
        DatePickerDialog picker = new DatePickerDialog(
                getActivity(),
                null, // instead of a listener
                2022, 2, 9);
        picker.setCancelable(true);
        picker.setCanceledOnTouchOutside(true);
        picker.setButton(DialogInterface.BUTTON_POSITIVE, "OK",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        d.setText((picker.getDatePicker().getMonth()+ "/"
                                + picker.getDatePicker().getDayOfMonth() + "/" + picker.getDatePicker()
                                .getYear()));
                    }
                });
        picker.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
        picker.show();
    }

    @Override
    public void onAttach(@NonNull Context context){
        super.onAttach(context);

        if(context instanceof CreateTask.Isend)
            mSend = (CreateTask.Isend)context ;
    }

    CreateTask.Isend mSend;

    public interface Isend{
        void newTask(Task a);

    }

    }