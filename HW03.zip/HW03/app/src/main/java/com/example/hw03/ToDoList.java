package com.example.hw03;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class ToDoList extends Fragment {

    final String TAG = "demo";
    final static public int REQ_CODE = 100;
    final static public String USE_KEY = "USE KEY";
    int num;
    TextView numTask;
    TextView name;
    TextView date;
    TextView priority;
    ArrayList<Task> l= new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_to_do_list, container, false);

        l = CustomFragment.getTask(MainActivity.list);

        name = view.findViewById(R.id.textViewName1);
        date = view.findViewById(R.id.textViewDate2);
        priority = view.findViewById(R.id.textViewPriority1);

        if(l.size()==0){
            name.setText("None");
            date.setText("");
            priority.setText("");
        }
        else{
            name.setText(l.get(0).getName());
            date.setText(l.get(0).getDate());
            priority.setText(l.get(0).getPriority());
        }

        //Pull what task to delete
        /*if (getIntent() != null && getIntent().getExtras() != null && getIntent().hasExtra(DisplayTask.DATA_ENTERED)) {
            int task = getIntent().getIntExtra(DisplayTask.DATA_ENTERED, 9);
            num = task;
            list.remove(num);

            if(list.size()==0){
                name.setText("None");
                date.setText("");
                priority.setText("");
            }
            else{
                name.setText(list.get(0).getName());
                date.setText(list.get(0).getDate());
                priority.setText(list.get(0).getPriority());
            }

        }*/
        //set Text for num of Task
        numTask = view.findViewById(R.id.textView);
        numTask.setText("You have " + l.size() + " tasks");


        //View Tasks --> Calls Alert Box
        view.findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onCreateDialog();

            }

        });
        //Create Task
        view.findViewById(R.id.button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }

        });

        // Inflate the layout for this fragment
        return view;

    }

    //(Alert Box)
    public void onCreateDialog() {

        CharSequence[] myObjects = new CharSequence[l.size()];
        for (int i = 0; i < l.size(); i++) {
            myObjects[i] = l.get(i).getName();
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Select Task");
        builder.setItems(myObjects, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                        Task t = new Task(l.get(which).getName(), l.get(which).getDate(), l.get(which).getPriority(), which);
                        mTask.setTask(t);

            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {

            }
        });
        builder.create();
        builder.show();


    }

   /* @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            Log.d(TAG, "onActivityResult: ");
            if (data != null && data.hasExtra(CreateTask.USER_KEY)) {
                Task dataEntered = (Task) data.getSerializableExtra(CreateTask.USER_KEY);
                l.add(dataEntered);
                numTask.setText("You have " + l.size() + " tasks");
                if(l.size()==0){
                    name.setText("None");
                    date.setText("");
                    priority.setText("");
                }
                else{
                    name.setText(l.get(0).getName());
                    date.setText(l.get(0).getDate());
                    priority.setText(l.get(0).getPriority());
                }
            } else if (resultCode == RESULT_CANCELED) {
                Log.d(TAG, "onActivityResult: RESULT_CANCELLED");
            }
        }
    }*/
   @Override
   public void onAttach(@NonNull Context context){
       super.onAttach(context);

       if(context instanceof Itask)
           mTask = (Itask)context ;
   }

    Itask mTask;

   public interface Itask{
       void setTask(Task t);

   }


}
