package com.example.hw02;

public class Task {
    String name;
    String date;
    String priority;
    public Task(String n, String d, String p){
        this.name = n;
        this.date = d;
        this.priority = p;
    }

}
