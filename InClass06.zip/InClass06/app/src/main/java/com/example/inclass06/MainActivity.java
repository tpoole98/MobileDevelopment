/*
Assignment InClass 06
InCLass06
Tristan Lee Poole
 */
package com.example.inclass06;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.material.slider.Slider;

import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    ExecutorService threadPool;
    Button btn;
    Slider slider;
    TextView text;
    TextView prog;
    ProgressBar progress;
    Handler handler;
    int v;
    int num = 0;
    ArrayList<String> list = new ArrayList<>();
    ListView listView;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Main Activity");
        prog = findViewById(R.id.textStatus);
        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message message) {
                Message msg = message;
                switch(msg.what){
                    case doWork.STATUS_START:
                        btn.setClickable(false);
                        progress.setVisibility(View.VISIBLE);
                        list.clear();

                        break;
                    case doWork.STATUS_PROG:
                        num++;
                        list.add(String.valueOf((double)message.obj));
                        adapter = new ArrayAdapter<>(getBaseContext(), android.R.layout.simple_list_item_1,android.R.id.text1, list);
                        listView = findViewById(R.id.listView);
                        listView.setAdapter(adapter);
                        prog.setText(num + "/" + v);



                        break;
                    case doWork.STATUS_STOP:
                        btn.setClickable(true);

                        break;

                }
                return false;
            }
        });

        threadPool = Executors.newFixedThreadPool(2);
        btn = findViewById(R.id.button);
        slider = findViewById(R.id.slider);
        text = findViewById(R.id.textView2);
        progress = findViewById(R.id.progressBar);

        slider.addOnChangeListener(new Slider.OnChangeListener(){
            @Override
            public void onValueChange(@NonNull Slider slider, float value, boolean fromUser){
                v = (int)value;
                text.setText(v + " Times");
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                threadPool.execute(new doWork());
            }
        });

    }
    class doWork implements Runnable{
        static final int STATUS_START = 0x00;
        static final int STATUS_PROG = 0x01;
        static final int STATUS_STOP = 0x02;
        Double d;


        @Override
        public void run() {

            Message startMessage = new Message();
            startMessage.what = STATUS_START;
            handler.sendMessage(startMessage);

            for(int i = 0; i < v; i++) {
                d = HeavyWork.getNumber();
                Message message = new Message();
                message.what = STATUS_PROG;
                message.obj = d;
                handler.sendMessage(message);
            }

            Message stopMessage = new Message();
            stopMessage.what = STATUS_STOP;
            handler.sendMessage(stopMessage);
        }
    }
}